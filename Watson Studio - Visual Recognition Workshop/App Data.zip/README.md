# How to train the dog model



## Class names
The sample notebooks and apps expect the classes to be named the same as the training files, but without the `'flags-'` prefix and without the `.zip` extension:




